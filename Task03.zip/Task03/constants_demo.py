BASE_RATE = 30.00
STD_FAT = 3.5
STD_SNF = 8.5
FAT_STEP_VALUE = 0.40
SNF_STEP_VALUE = 0.30
STEP_SIZE = 0.1
MIN_FAT, MAX_FAT = 2.0, 7.0
RATE_CARD = {"base": 30.0, "fat": 0.40, "snf": 0.30}

x = 10; print(type(x)); x = "ten"; print(type(x))   # dynamic typing
a, b = 3, 5; a, b = b, a; print(a, b)               # swap
c = d = 0; e, f = 1, 2; print(c, d, e, f)           # multiple assignment
BASE_RATE = 99.0   # Python allows this: constants are convention only
print(BASE_RATE)
