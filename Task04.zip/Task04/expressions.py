import math
print("(4.2-3.5)/0.1 =", (4.2 - 3.5) / 0.1, "-> round:", round((4.2 - 3.5) / 0.1))
print("(3.1-3.5)/0.1 =", (3.1 - 3.5) / 0.1)
print("(8.7-8.5)/0.1 =", (8.7 - 8.5) / 0.1)
print("-2**2 =", -2 ** 2, " (-2)**2 =", (-2) ** 2, " 2**3**2 =", 2 ** 3 ** 2)
print("negatives: round(-2.5)=", round(-2.5), "int(-2.5)=", int(-2.5), "floor(-2.5)=", math.floor(-2.5))
BASE, FATV, SNFV = 30.0, 0.40, 0.30
for fat, snf in [(4.2, 8.5), (3.1, 8.5)]:
    raw = (fat - 3.5) / 0.1
    for name, fn in [("round", round), ("int", int), ("floor", math.floor)]:
        steps = fn(raw)
        print(f"fat {fat}: raw={raw!r:20} {name:5} steps={steps:3} rate={BASE + steps*FATV:.2f}")
fat = 4.2
print(2.0 <= fat <= 7.0, 2.0 <= fat and fat <= 7.0, not (fat < 2.0 or fat > 7.0))
