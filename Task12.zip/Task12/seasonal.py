"""Seasonal rate card + bonus. Fat/SNF readings may have 2 decimals; steps are pro-rata (fractional)."""
from decimal import Decimal as D, ROUND_HALF_UP
PAISE = D("0.01")
STD_FAT, STD_SNF, STEP = D("3.5"), D("8.5"), D("0.1")
SNF_STEP_VALUE = D("0.30")
RATE_CARDS = {
    "normal": {"base": D("30.00"), "fat_step": D("0.40")},
    "summer": {"base": D("32.00"), "fat_step": D("0.45")},   # April-June
}
BONUS_LIMIT, BONUS_PER_LITRE = D("500"), D("0.50")
SUMMER_MONTHS = (4, 5, 6)

def money(x): return x.quantize(PAISE, rounding=ROUND_HALF_UP)
def season_for_month(month): return "summer" if month in SUMMER_MONTHS else "normal"

def rate_per_litre(fat, snf, season="normal"):
    card = RATE_CARDS[season]
    return card["base"] + (fat - STD_FAT) / STEP * card["fat_step"] + (snf - STD_SNF) / STEP * SNF_STEP_VALUE

def payout(litres, fat, snf, season="normal"):
    return litres * rate_per_litre(fat, snf, season)

def bonus(total_litres):
    return total_litres * BONUS_PER_LITRE if total_litres > BONUS_LIMIT else D("0")

def ten_day_total(entries, season="normal"):
    total = sum((payout(l, f, s, season) for l, f, s in entries), D("0"))
    litres = sum((l for l, _, _ in entries), D("0"))
    return money(total + bonus(litres))

if __name__ == "__main__":
    print("rate 4.25/8.65 normal:", money(rate_per_litre(D("4.25"), D("8.65"))))
    print("rate 4.25/8.65 summer:", money(rate_per_litre(D("4.25"), D("8.65"), "summer")))
    small = [(D("10"), D("3.50"), D("8.50"))] * 10                    # 100 L
    big = [(D("60"), D("4.20"), D("8.70"))] * 10                      # 600 L
    assert ten_day_total(small, "normal") == D("3000.00")
    assert ten_day_total(small, "summer") == D("3200.00")             # 100 x 32
    assert ten_day_total(big, "normal") == money(600 * D("33.40") + 300)
    assert ten_day_total(big, "summer") == money(600 * (D("32.00") + 7*D("0.45") + 2*D("0.30")) + 300)
    assert bonus(D("500")) == 0 and bonus(D("500.01")) > 0            # strictly more than 500
    print("small normal/summer:", ten_day_total(small), ten_day_total(small, "summer"))
    print("big normal/summer  :", ten_day_total(big), ten_day_total(big, "summer"))
    print("ALL SEASONAL TESTS PASSED")
