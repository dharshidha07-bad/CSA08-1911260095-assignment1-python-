"""Worked examples: original (Task 7) design applied to two-decimal analyser readings."""
import sys
sys.path.insert(0, "../Task07")
import milkrate as old
import seasonal as new
from decimal import Decimal as D

print(f"{'fat':>5}{'snf':>6}{'raw fat steps':>22}{'old steps':>10}{'old rate':>10}{'new rate (normal)':>19}")
for fat, snf in [(4.25, 8.5), (4.35, 8.5), (4.45, 8.5), (4.15, 8.5), (3.55, 8.65)]:
    raw = (fat - 3.5) / 0.1
    print(f"{fat:>5}{snf:>6}{raw!r:>22}{round(raw):>10}{old.rate_per_litre(fat, snf):>10.2f}"
          f"{new.money(new.rate_per_litre(D(str(fat)), D(str(snf)))):>19}")
print("summer, original design cannot express: base 32.00 / fat step 0.45 / bonus")
