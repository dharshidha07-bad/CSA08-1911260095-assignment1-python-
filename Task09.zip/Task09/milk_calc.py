"""Final calculator: Decimal arithmetic, validation, functions."""
from decimal import Decimal, ROUND_HALF_UP

BASE_RATE = Decimal("30.00")
FAT_STEP_VALUE = Decimal("0.40")
SNF_STEP_VALUE = Decimal("0.30")
STD_FAT, STD_SNF, STEP = Decimal("3.5"), Decimal("8.5"), Decimal("0.1")
MIN_FAT, MAX_FAT = Decimal("2.0"), Decimal("7.0")
MIN_SNF, MAX_SNF = Decimal("6.0"), Decimal("10.0")   # assumption
PAISE = Decimal("0.01")

def money(x):
    return x.quantize(PAISE, rounding=ROUND_HALF_UP)

def parse_decimal(text):
    """Convert text to Decimal; raise ValueError for bad input (e.g. '8,5', 'eight')."""
    try:
        value = Decimal(text.strip())
    except Exception:
        raise ValueError(f"not a number: {text!r}")
    if not value.is_finite():
        raise ValueError(f"not a finite number: {text!r}")
    return value

def validate(litres, fat, snf):
    if litres < 0:
        raise ValueError("litres must be non-negative")
    if not MIN_FAT <= fat <= MAX_FAT:
        raise ValueError("fat must be between 2.0 and 7.0")
    if not MIN_SNF <= snf <= MAX_SNF:
        raise ValueError("SNF must be between 6.0 and 10.0")

def steps(value, standard):
    return ((value - standard) / STEP).to_integral_value(rounding=ROUND_HALF_UP)

def rate_per_litre(fat, snf):
    return money(BASE_RATE + steps(fat, STD_FAT) * FAT_STEP_VALUE
                 + steps(snf, STD_SNF) * SNF_STEP_VALUE)

def payout(litres, fat, snf):
    return money(litres * rate_per_litre(fat, snf))

def ten_day_total(entries):
    return sum((payout(l, f, s) for l, f, s in entries), Decimal("0.00"))

def process(litres_t, fat_t, snf_t):
    l, f, s = parse_decimal(litres_t), parse_decimal(fat_t), parse_decimal(snf_t)
    validate(l, f, s)
    return payout(l, f, s)
