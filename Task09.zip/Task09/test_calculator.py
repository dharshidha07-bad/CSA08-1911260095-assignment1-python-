from decimal import Decimal as D
from milk_calc import *

cases = [
 ("above standard", ("8.5","4.2","8.7"), D("283.90")),
 ("below standard", ("12","3.1","8.3"), D("333.60")),
 ("boundary 3.5/8.5", ("10","3.5","8.5"), D("300.00")),
 ("lowest fat 2.0", ("10","2.0","8.5"), D("240.00")),
 ("highest fat 7.0", ("10","7.0","8.5"), D("440.00")),
 ("invalid text", ("10","eight","8.5"), ValueError),
 ("comma decimal", ("10","3,5","8.5"), ValueError),
 ("negative litres", ("-5","3.5","8.5"), ValueError),
 ("fat too high", ("10","7.1","8.5"), ValueError),
 ("fat too low", ("10","1.9","8.5"), ValueError),
]
print(f"{'Case':18}{'Input':26}{'Expected':>12}{'Actual':>12}  Result")
for name, inp, exp in cases:
    try:
        act = process(*inp)
    except ValueError:
        act = ValueError
    ok = act == exp
    exp_s = getattr(exp, "__name__", str(exp))
    act_s = getattr(act, "__name__", str(act))
    status = "PASS" if ok else "FAIL"
    print(f"{name:18}{str(inp):26}{exp_s:>12}{act_s:>12}  {status}")
    assert ok

rows = [("10", "3.5", "8.5"), ("8.5", "4.2", "8.7"), ("12", "3.1", "8.3"),
        ("20", "4.0", "8.6"), ("5", "3.6", "8.4")]
entries = [(D(a), D(b), D(c)) for a, b, c in rows]
manual = (D("300.00") + D("283.90") + D("333.60")
          + D("20") * D("32.30") + D("5") * D("30.10"))
print("5-entry total actual:", ten_day_total(entries), "manual:", manual)
assert ten_day_total(entries) == manual
print("ALL TESTS PASSED")
