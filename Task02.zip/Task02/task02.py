import sys
from decimal import Decimal

payments = ["33.40"] * 1000 + ["0.10"] * 3

def total_float(items):
    total = 0.0
    for amount in items:
        total += float(amount)
    return total

def total_decimal(items):
    """Add the amounts exactly using Decimal built from the strings."""
    total = Decimal("0")
    for amount in items:
        total += Decimal(amount)
    return total

def total_decimal_from_float(items):
    """Variant: Decimal(float(amount)) - inherits binary float error."""
    total = Decimal("0")
    for amount in items:
        total += Decimal(float(amount))
    return total

def total_paise(items):
    """Integer paise: exact, fastest, but needs conversion in and out."""
    paise = 0
    for amount in items:
        paise += round(float(amount) * 100)
    return paise / 100, paise

def total_float_rounded(items):
    total = 0.0
    for amount in items:
        total = round(total + float(amount), 2)
    return total

print("float :", total_float(payments))
print("Decimal:", total_decimal(payments))
print(0.1 + 0.2 == 0.3, Decimal("0.1") + Decimal("0.2") == Decimal("0.3"))
print("Decimal(float(amount)):", total_decimal_from_float(payments))
print("integer paise:", total_paise(payments))
print("float + round each add:", total_float_rounded(payments))
print("getsizeof float  :", sys.getsizeof(1.5))
print("getsizeof int    :", sys.getsizeof(3340))
print("getsizeof Decimal:", sys.getsizeof(Decimal("33.40")))
for v in (10, 10.0, "10", True, [10, 8.5]):
    print(repr(v), type(v))
print(7 / 2, 7 // 2, 7 % 2, -7 // 2)
