import sys
import milkrate as mr
print("Payout for 20 L, 4.0 fat, 8.6 SNF:", mr.payout(20, 4.0, 8.6))
print("milkrate cached in sys.modules:", "milkrate" in sys.modules)
