BASE_RATE, FAT_STEP_VALUE, SNF_STEP_VALUE = 30.00, 0.40, 0.30

def rate_per_litre(fat, snf):
    """Return price per litre for the given fat and SNF percentage."""
    fat_steps = round((fat - 3.5) / 0.1)
    snf_steps = round((snf - 8.5) / 0.1)
    return round(BASE_RATE + fat_steps * FAT_STEP_VALUE + snf_steps * SNF_STEP_VALUE, 2)

def payout(litres, fat, snf):
    """Return payment amount for one delivery."""
    return round(litres * rate_per_litre(fat, snf), 2)

def ten_day_total(entries):
    """Return total payment for a farmer; entries = [(litres, fat, snf), ...]."""
    return round(sum(payout(l, f, s) for l, f, s in entries), 2)

if __name__ == "__main__":
    week = [(10, 3.5, 8.5), (8.5, 4.2, 8.7), (12, 3.1, 8.3)]
    print(ten_day_total(week))
    square = lambda x: x * x
    print(square(4))
