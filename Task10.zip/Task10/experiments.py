import random, time
from decimal import Decimal, ROUND_HALF_UP
random.seed(1)
P = Decimal("0.01")
def gen(n):  # exact payments in 3 decimals, as products litres * rate can give
    return [Decimal(random.randint(10000, 60000)) / 1000 for _ in range(n)]
print(f"{'n':>8}{'float total':>22}{'Decimal total':>16}{'round each':>14}{'t_float(s)':>12}{'t_dec(s)':>10}")
for n in (300, 6000, 150000):
    data = gen(n); fl = [float(x) for x in data]
    t = time.perf_counter(); tf = sum(fl); t_f = time.perf_counter() - t
    t = time.perf_counter(); td = sum(data, Decimal(0)); t_d = time.perf_counter() - t
    each = sum((x.quantize(P, rounding=ROUND_HALF_UP) for x in data), Decimal(0))
    print(f"{n:>8}{tf:>22.10f}{td.quantize(P, rounding=ROUND_HALF_UP):>16}{each:>14}{t_f:>12.6f}{t_d:>10.6f}")
# rate-table vs recalculation
import sys; sys.path.insert(0, "../Task09")
from milk_calc import rate_per_litre
def random_pair():
    fat = Decimal(str(round(random.uniform(2, 7), 1)))
    snf = Decimal(str(round(random.uniform(7, 9.5), 1)))
    return fat, snf
pairs = [random_pair() for _ in range(150000)]
t = time.perf_counter(); [rate_per_litre(f, s) for f, s in pairs]; t_calc = time.perf_counter() - t
table = {}
t = time.perf_counter()
for p in pairs:
    if p not in table: table[p] = rate_per_litre(*p)
    _ = table[p]
t_tab = time.perf_counter() - t
print(f"recalculate 150000: {t_calc:.3f}s | dict lookup: {t_tab:.3f}s | distinct pairs k = {len(table)}")
