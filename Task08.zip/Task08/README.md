# Task 8 - Plan the Algorithm Before Coding
Pseudocode, flowchart and hand-trace are in the assignment report, Task 8.
Hand-trace check: payments 300.00, 283.90, 333.60 -> running total 917.50
(matches `python3 ../Task06/functions.py`).
