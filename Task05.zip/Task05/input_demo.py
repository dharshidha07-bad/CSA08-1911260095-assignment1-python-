def parse_float(text):
    try:
        return float(text)
    except ValueError:
        return None

def parse_with_string_checks(text):
    t = text.strip()
    if t.replace(".", "", 1).isdigit():
        return float(t)
    return None

for s in ["8.5", "8,5", " 8.5 ", "eight"]:
    print(f"{s!r:8} try/except -> {parse_float(s)!s:5} | string checks -> {parse_with_string_checks(s)}")
amount = 283.9
print(f"[{amount:8.2f}] [{'F001':>6}] [{12:5d}]")

def read_float(prompt):          # interactive version
    while True:
        value = parse_float(input(prompt))
        if value is not None:
            return value
        print("Invalid number, try again.")
