# Task 11 - Recommend and Defend the Final Design
Recommendation: Decimal built from strings, ROUND_HALF_UP on each payment, sum of rounded payments,
rate card changed in one place and re-tested, stream entries with a running total per farmer for 150,000 farmers.
Evidence: Task09 test table and Task10 measurements. Full justification is in the report, Task 11.
